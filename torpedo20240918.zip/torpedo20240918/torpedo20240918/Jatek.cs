﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace torpedo20240918
{
    public class Jatek
    {
        public int v = 0;
        private Palya p = new Palya(10, 10);
        private int lox;
        private int loy;
        public string bekeres = "";
        

        public Jatek()
        {
            //lov
            do
            {
                Loves();
            } while ((from h in p.Hajok select h.elet).Sum() > 0);



        }

        public void Loves()
        {
            if (v == 0)
            {
                p.Kirajzol(true);
                v++;
            }  
            else
                p.Kirajzol(false);

            
            Console.SetCursorPosition(0, 13);
            Console.Write("Lövés oszlopa (X koordinátája v Kilépés): ");
            bekeres = Console.ReadLine();

            if (int.TryParse(bekeres, out lox))
            {
                lox = int.Parse(bekeres) - 1;
                Console.Write("Lövés sora (Y koordinátája): ");
                loy = int.Parse(Console.ReadLine()) - 1;


                if (p.LovesTalalt(lox, loy) != null)
                {
                    Pont pont = p.LovesTalalt(lox, loy);
                    pont.Hajo.elet--;
                    pont.Talalt = true;
                    Console.WriteLine("talált");
                }
                else
                {
                    Pont nemhajo = new Pont(lox, loy, null);
                    nemhajo.Talalt = true;
                    p.HajoPontLerak(nemhajo);
                    Console.WriteLine("nem talált");
                }
                Thread.Sleep(1000);
                Console.Clear();
            }

            else if (bekeres.ToLower() == "kilépés")
            {
                System.Environment.Exit(0);
            }
                

            
        }

    }
}
