﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace torpedo20240918
{
    public class Palya
    {
        private List<Pont> Tenger = new List<Pont>();
        private int OszlopSzam;
        private int SorSzam;
        public List<Hajo> Hajok = new List<Hajo>();

        public int OszlopSZ { get { return OszlopSzam; } }
        public int SorSZ { get { return SorSzam; } }

        public void Kirajzol(bool hajokkal)
        {
            keret();
            if (hajokkal)
            {
                foreach (Pont p in Tenger)
                {
                    if (p.Hajo != null)
                    {
                        Console.SetCursorPosition(p.X + 1, p.Y + 1);
                        Console.BackgroundColor = ConsoleColor.Black;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write(p.Hajo.Meret);
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.Black;
                    }
                }
            }
            else
            {
                foreach (Pont p in Tenger)
                {
                    if (p.Talalt == true && p.Hajo != null)
                    {
                        if (p.Hajo.elet == 0)
                        {
                            Console.SetCursorPosition(p.X + 1, p.Y + 1);
                            Console.BackgroundColor = ConsoleColor.Red;
                            Console.ForegroundColor = ConsoleColor.Black;
                            Console.Write("O");
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        else
                        {
                            Console.SetCursorPosition(p.X + 1, p.Y + 1);
                            Console.BackgroundColor = ConsoleColor.Yellow;
                            Console.ForegroundColor = ConsoleColor.Black;
                            Console.Write("O");
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.BackgroundColor = ConsoleColor.Black;
                        }
                        

                    }
                    
                    else if(p.Hajo == null && p.Talalt == true)
                    {
                        Console.SetCursorPosition(p.X + 1, p.Y + 1);
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.Write("X");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.Black;
                    }
                    else if (p.Hajo != null && p.Talalt==false)
                    {
                        Console.SetCursorPosition(p.X + 1, p.Y + 1);
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.ForegroundColor = ConsoleColor.Black;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.Black;
                    }
                }
            }

        }

        public Palya(int osz, int ssz)
        {
            OszlopSzam = osz;
            SorSzam = ssz;
            HajotLerak();
        }

        public void HajotLerak()
        {
            Hajok.Add(new Hajo(2, this, true));
            Hajok.Add(new Hajo(3, this, true));
            Hajok.Add(new Hajo(3, this, true));
            Hajok.Add(new Hajo(4, this, true));
            Hajok.Add(new Hajo(5, this, true));
        }

        public void HajoPontLerak(Pont p)
        {
            Tenger.Add(p);
        }

        public void keret()
        {
            for (int i = 0; i < SorSzam + 2; i++)
            {
                for (int j = 0; j < OszlopSzam + 2; j++)
                {
                    if (i == 0 || j == 0 || i == SorSzam + 1 || j == OszlopSzam + 1)
                    {
                        Console.BackgroundColor = ConsoleColor.Black;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Write("#");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.BackgroundColor = ConsoleColor.Black;
                    }
                    else
                    {
                        Console.BackgroundColor = ConsoleColor.Black;
                        Console.Write(" ");
                        Console.BackgroundColor = ConsoleColor.Black;
                    }
                }
                Console.WriteLine();
            }
        }

        public bool FoglaltMezo(int x, int y)
        {
            bool foglalt = false;
            foreach (Pont p in Tenger)
            {
                if (p.X == x && p.Y == y)
                {
                    foglalt = true;
                }
            }
            return foglalt;
        }


        public Pont LovesTalalt(int x, int y)
        {
            foreach (Pont p in Tenger)
            {
                if (p.X == x && p.Y == y)
                {
                    if (p.Hajo != null && p.Talalt == false)
                    {
                        return p;
                    }
                }
            }

            return null;
        }

    }
}
