﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using torpedo20240918;

namespace torpedo20240918
{
    public class Hajo
    {
        public int meret;
        public int elet;
        public int irany; //0-vízszintes, 1-függőleges
        Palya palya;
        public int Meret { get { return meret; } }

        public void KoordinatakBekerese()
        {
            int kezdooszlop;
            int kezdosor;

            do
            {
                Console.Write("Hányadik oszloptól (X) kezdődjön a hajó: ");
                kezdooszlop = int.Parse(Console.ReadLine()) - 1;
                Console.Write("Hányadik sortól (Y) kezdődjön a hajó: ");
                kezdosor = int.Parse(Console.ReadLine()) - 1;
                Console.Write("Hajó iránya: 0-vízszintes, 1-függőlges: ");
                irany = int.Parse(Console.ReadLine());
            } while (!Lerakhato(kezdooszlop, kezdosor));
            Console.Clear();
            Lerak(kezdooszlop, kezdosor);


        }

        public Hajo(int meret, Palya p, bool generalt = false)
        {
            this.meret = meret;
            elet = meret;
            palya = p;
            if (generalt == false)
            {
                KoordinatakBekerese();
            }
            else
            {
                KoordinataGeneral();
            }


        }

        public bool Lerakhato(int x, int y)
        {
            int p_oszlopszam = palya.OszlopSZ;
            int p_sorszam = palya.SorSZ;

            for (int i = 0; i < meret; i++)
            {
                if (irany == 0)
                {
                    if (x + i >= p_oszlopszam || y > p_sorszam)
                    {
                        return false;
                    }

                }
                else
                {
                    if (x > p_oszlopszam || y + i >= p_sorszam)
                    {
                        return false;
                    }
                }
            }


            for (int i = 0; i < meret; i++)
            {
                if (irany == 0)
                {
                    if (palya.FoglaltMezo(x + i, y))
                    {
                        return false;
                    }

                }
                else
                {
                    if (palya.FoglaltMezo(x, y + i))
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public void Lerak(int x, int y)
        {
            for (int i = 0; i < meret; i++)
            {
                if (irany == 0)
                {
                    palya.HajoPontLerak(new Pont(x + i, y, this));
                }
                else
                {
                    palya.HajoPontLerak(new Pont(x, y + i, this));
                }

            }
        }

        public void KoordinataGeneral()
        {
            int kezdooszlop;
            int kezdosor;
            Random r = new Random();

            do
            {
                Console.Write("Hányadik oszloptól (X) kezdődjön a hajó: ");
                kezdooszlop = r.Next(0, palya.OszlopSZ);
                Console.Write("Hányadik sortól (Y) kezdődjön a hajó: ");
                kezdosor = r.Next(0, palya.SorSZ);
                Console.Write("Hajó iránya: 0-vízszintes, 1-függőlges: ");
                irany = r.Next(0, 2);
            } while (!Lerakhato(kezdooszlop, kezdosor));
            Console.Clear();
            Lerak(kezdooszlop, kezdosor);
        }
    }
}
