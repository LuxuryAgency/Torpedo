﻿namespace torpedo20240918
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Jatek j = new Jatek();
            Console.ReadLine();
        }
    }
}
