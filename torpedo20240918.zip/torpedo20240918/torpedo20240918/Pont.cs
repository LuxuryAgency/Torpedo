﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace torpedo20240918
{
    public class Pont
    {
        // koordinata 1.oszlop, 2.sor
        public int X { get; set; }
        public int Y { get; set; }
        public Hajo? Hajo { get; set; }
        public bool Talalt { get; set; }

        public Pont(int x, int y, Hajo h)
        {
            X = x;
            Y = y;
            Hajo = h;
            Talalt = false;
        }

    }
}
